<?php

namespace App\Http\Controllers;

use App\Exceptions\BarangException;
use App\Models\Barang;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Yajra\DataTables\DataTables;

class BarangController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Barang::select('*');
            return DataTables::of($data)
                ->addColumn('action', function ($row) {
                    $btn = '<a href="' . route('data.edit', $row->id) . '" class="btn btn-info">Edit</a>';
                    $btn .= ' <button class="btn btn-danger delete" data-id="' . $row->id . '">Delete</button>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }     
        return view('page.admin.data.barang');
    }

    public function create()
    {
        return view('page.admin.data.formbarang');
    }

    public function store(Request $request)
    {
        try {
            $validatedData =$request->validate([ 
                'nama_barang' => 'required',
                'satuan' => 'required',
                'stok' => 'required|integer',
                'harga_barang' => 'required|integer',
            ]);

            $barang = new Barang($validatedData);
            $barang->save();

            Log::info('Barang created successfully: ' . $barang->nama_barang);

            return redirect()->route('data.barang')->with('success', 'Data Berhasil Disimpan');
        } catch (ValidationException $e) {
            Log::error('Validation failed while creating a Barang: ' . $e->getMessage());
            return redirect()->back()->withErrors($e->errors())->withInput();
        }
    }

    public function show($id)
    {
        $data = Barang::find($id);
        return view('page.admin.data.tampilbarang', compact('data'));
    }

    public function tampilkandata($id)
    {
        $data = Barang::find($id);
        return view('page.admin.data.tampilbarang', compact('data'));
    }

    public function edit($id)
    {
        $data = Barang::find($id);
        return view('page.admin.data.tampilbarang', compact('data'));
    }

    public function update(Request $request, $id)
    {
        try {
            $validatedData = $request->validate([
                'nama_barang' => 'required',
                'satuan' => 'required',
                'stok' => 'required|integer',
                'harga_barang' => 'required|integer',
            ]);

            $barang = Barang::find($id);
            $barang->update($validatedData);
            Log::info('barang updated successfully: ' . $barang->nama_barang);

            return redirect()->route('data.barang')->with('success', 'Data Berhasil Edit');
        } catch (ValidationException $e) {
            Log::error('Validation failed while updating a barang: ' . $e->getMessage());
            return redirect()->back()->withErrors($e->errors())->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $barang = Barang::find($id);

            if (!$barang) {
                throw new BarangException('Data not found.');
            }

            $barang->delete();
            Log::info('Barang deleted successfully: ' . $barang->nama_barang);

            return response()->json(['success' => 'Data Berhasil Dihapus']);
        } catch (BarangException $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }


}