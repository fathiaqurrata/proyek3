<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exceptions\BarangException;
use App\Models\Kasir;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;
use Yajra\DataTables\DataTables;
class KasirPolbanController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Kasir::select('*');
            return DataTables::of($data)
                ->addColumn('action', function ($row) {
                    $btn = '<a href="' . route('data.edit', $row->id) . '" class="btn btn-info">Edit</a>';
                    $btn .= ' <button class="btn btn-danger delete" data-id="' . $row->id . '">Delete</button>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }     
        return view('page.admin.kasir.data');
    }

    public function create()
    {
        return view('page.admin.kasir.formdata');
    }

    public function store(Request $request)
    {
        try {
            $validatedData =$request->validate([ 
                'nama' => 'required',
                'hp' => 'required|integer',
            ]);

            $kasir = new Kasir($validatedData);
            $kasir->save();

            Log::info('Barang created successfully: ' . $kasir->nama);

            return redirect()->route('kasir.data')->with('success', 'Data Berhasil Disimpan');
        } catch (ValidationException $e) {
            Log::error('Validation failed while creating a Barang: ' . $e->getMessage());
            return redirect()->back()->withErrors($e->errors())->withInput();
        }
    }

    public function show($id)
    {
        $data = Kasir::find($id);
        return view('page.admin.kasir.tampildata', compact('data'));
    }

    public function tampilkandata($id)
    {
        $data = Kasir::find($id);
        return view('page.admin.kasir.tampildata', compact('data'));
    }

    public function edit($id)
    {
        $data = Kasir::find($id);
        return view('page.admin.kasir.tampildata', compact('data'));
    }

    public function update(Request $request, $id)
    {
        try {
            $validatedData = $request->validate([
                'nama' => 'required',
                'hp' => 'required|integer',
            ]);

            $kasir = Kasir::find($id);
            $kasir->update($validatedData);
            Log::info('barang updated successfully: ' . $kasir->nama);

            return redirect()->route('kasir.data')->with('success', 'Data Berhasil Edit');
        } catch (ValidationException $e) {
            Log::error('Validation failed while updating a barang: ' . $e->getMessage());
            return redirect()->back()->withErrors($e->errors())->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $kasir = Kasir::find($id);

            if (!$kasir) {
                throw new BarangException('Data not found.');
            }

            $kasir->delete();
            Log::info('Barang deleted successfully: ' . $kasir->nama_barang);

            return response()->json(['success' => 'Data Berhasil Dihapus']);
        } catch (BarangException $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }
}