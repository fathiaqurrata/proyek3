<?php

return [
    'TanggalFormat' => [
        "locale" => 'id',
        "timezone" => 'Asia/Jakarta'
    ]
];
