<?php

use App\Http\Controllers\AkunController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\KasirPolbanController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::group(['prefix' => 'dashboard/admin'], function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');

    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', [HomeController::class, 'profile'])->name('profile');
        Route::post('update', [HomeController::class, 'updateprofile'])->name('profile.update');
    });

    Route::controller(AkunController::class)
        ->prefix('akun')
        ->as('akun.')
        ->group(function () {
            Route::get('/', 'index')->name('index');
            Route::post('showdata', 'dataTable')->name('dataTable');
            Route::match(['get','post'],'tambah', 'tambahAkun')->name('add');
            Route::match(['get','post'],'{id}/ubah', 'ubahAkun')->name('edit');
            Route::delete('{id}/hapus', 'hapusAkun')->name('delete');
        });

    Route::controller(BarangController::class)
        ->prefix('data')
        ->as('data.')
        ->group(function () {
            Route::get('/barang', [BarangController::class, 'index'])->name('barang');
            Route::get('/formbarang', [BarangController::class, 'create'])->name('formbarang');
            Route::post('/store', [BarangController::class, 'store'])->name('store');
            Route::get('/show/{id}', [BarangController::class, 'show'])->name('show');
            Route::get('/barang/{id}/edit', [BarangController::class, 'edit'])->name('edit');
            Route::post('/update/{id}', [BarangController::class, 'update'])->name('update');
            Route::get('/tampilkandata/{id}',[BarangController::class, 'tampilkandata'])->name('tampilkandata');
            Route::delete('destroy/{id}', [BarangController::class, 'destroy'])->name('destroy');
        });

    Route::controller(KasirPolbanController::class)
        ->prefix('kasir')
        ->as('kasir.')
        ->group(function () {
            Route::get('/data', [KasirPolbanController::class, 'index'])->name('data');
            Route::get('/formdata', [KasirPolbanController::class, 'create'])->name('formdata');
            Route::post('/store', [KasirPolbanController::class, 'store'])->name('store');
            Route::get('/show/{id}', [KasirPolbanController::class, 'show'])->name('show');
            Route::get('/data/{id}/edit', [KasirPolbanController::class, 'edit'])->name('edit');
            Route::post('/update/{id}', [KasirPolbanController::class, 'update'])->name('update');
            Route::get('/tampilkandata/{id}',[KasirPolbanController::class, 'tampilkandata'])->name('tampilkandata');
            Route::delete('destroy/{id}', [KasirPolbanController::class, 'destroy'])->name('destroy');
        });

});