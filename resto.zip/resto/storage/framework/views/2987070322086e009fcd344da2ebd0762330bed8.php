

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center mt-4 mb-4">Beli Tiket Film</h2>
        <form action="<?php echo e(route('pembelians.store')); ?>" method="POST" id="pembelianForm">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="film_id" class="form-label">Film</label>
                <select name="film_id" id="film_id" class="form-select">
                    <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($film->id); ?>" data-harga="<?php echo e($film->harga); ?>"><?php echo e($film->judul_film); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="jumlah_tiket" class="form-label">Jumlah Tiket</label>
                <select name="jumlah_tiket" id="jumlah_tiket" class="form-select">
                    <?php for($i = 1; $i <= 10; $i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <!-- Summary Section -->
            <div class="mb-3">
                <label for="total_harga" class="form-label">Total Harga Rp.<span id="total_harga_display">50,000</span></label>
                <input type="hidden" name="total_harga" id="total_harga" value="50000">
            </div>

            <div class="mb-3">
                <label for="jumlah_pembayaran" class="form-label">Jumlah Pembayaran</label>
                <input type="number" name="jumlah_pembayaran" id="jumlah_pembayaran" class="form-control">
                <?php $__errorArgs = ['jumlah_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Beli Tiket</button>
        </form>
    </div>
    <script>
        document.getElementById('film_id').addEventListener('change', calculateTotalHarga);
        document.getElementById('jumlah_tiket').addEventListener('change', calculateTotalHarga);

        function calculateTotalHarga() {
            var selectedOption = document.getElementById('film_id').options[document.getElementById('film_id').selectedIndex];
            var harga = parseFloat(selectedOption.getAttribute('data-harga'));
            var jumlahTiket = parseInt(document.getElementById('jumlah_tiket').value);
            var totalHarga = harga * jumlahTiket;

            document.getElementById('total_harga').value = totalHarga.toFixed(2);
            document.getElementById('total_harga_display').innerText = totalHarga.toFixed(2);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathia Q.A\Downloads\Proyek 3 Website\pbo_film_kelompok7\resources\views/pembelians/create.blade.php ENDPATH**/ ?>