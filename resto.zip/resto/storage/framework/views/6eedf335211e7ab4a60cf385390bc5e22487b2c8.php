

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center mt-4 mb-4">Data Pembelian Tiket</h2>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Film</th>
                    <th>Jumlah Tiket</th>
                    <th>Total Harga</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pembelians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembelian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pembelian->id); ?></td>
                        <td><?php echo e($pembelian->film->judul_film); ?></td>
                        <td><?php echo e($pembelian->jumlah_tiket); ?></td>
                        <td><?php echo e($pembelian->total_harga); ?></td>
                        <td>
                            <a href="<?php echo e(route('pembelians.edit', $pembelian->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('pembelians.destroy', $pembelian->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathia Q.A\Downloads\Proyek 3 Website\pbo_film_kelompok7\resources\views/pembelians/index.blade.php ENDPATH**/ ?>