<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
<?php /**PATH C:\Users\Fathia Q.A\Downloads\Proyek 3 Website\pbo_film_kelompok7\resources\views/layouts/components/control_sidebar.blade.php ENDPATH**/ ?>